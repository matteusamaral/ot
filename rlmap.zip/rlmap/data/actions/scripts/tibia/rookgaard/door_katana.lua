function onUse(cid, item, fromPosition, itemEx, toPosition)
	return false
end