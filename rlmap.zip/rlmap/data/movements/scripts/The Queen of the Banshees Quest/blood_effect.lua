function onAddItem(moveitem, tileitem, pos)
 
	if moveitem.itemid == 2025 then
		doSendMagicEffect({x=32243, y=31891, z=14}, 0)
		doSendMagicEffect({x=32242, y=31891, z=14}, 0)
		doSendMagicEffect({x=32242, y=31892, z=14}, 0)
		doSendMagicEffect({x=32242, y=31893, z=14}, 0)
		doSendMagicEffect({x=32243, y=31893, z=14}, 0)
	end
end