--if you want to enable exp_stages, make sure that you have experience_stages = true at your config.lua

stages = {
	{minLevel = 1, maxLevel = 40, multiplier = 60},
	{minLevel = 41, maxLevel = 60, multiplier = 50},
	{minLevel = 61, maxLevel = 80, multiplier = 40},
	{minLevel = 81, maxLevel = 100, multiplier = 30}
}